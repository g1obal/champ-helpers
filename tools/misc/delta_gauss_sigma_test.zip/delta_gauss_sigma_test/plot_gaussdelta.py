"""
Plot the function fitted and delta values with respect to gauss sigma.
These delta values are required to have acceptances around 0.5.

The fit function is used to generate delta values for input files of VMC runs. 

The results will be used in input generator.

Author: Gokhan Oztarhan
Created date: 20/01/2022
Last modified: 20/01/2022
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


df = pd.read_csv('data_au.csv')

df = df.sort_values('gauss_sigma')

mask_low = df['gauss_sigma'] <= 1
mask_mid = np.logical_and(df['gauss_sigma'] > 1, df['gauss_sigma'] <= 5.5)
mask_high = df['gauss_sigma'] > 5.5

x_low = df['gauss_sigma'][mask_low]
y_low = df['delta'][mask_low]
poly_coef_low = np.polyfit(x_low, y_low, 1)

x_mid = df['gauss_sigma'][mask_mid]
y_mid = df['delta'][mask_mid]
poly_coef_mid = np.polyfit(x_mid, y_mid, 7)

x_high = df['gauss_sigma'][mask_high]
y_high = df['delta'][mask_high]
poly_coef_high = np.polyfit(x_high, y_high, 1)

x = df['gauss_sigma']
y = df['delta']

plt.plot(x, y, 'bo')
plt.plot(x_low, np.polyval(poly_coef_low, x_low), 'rx')
plt.plot(x_mid, np.polyval(poly_coef_mid, x_mid), 'gx')
plt.plot(x_high, np.polyval(poly_coef_high, x_high), 'rx')
plt.show()

print('poly_coef_low', poly_coef_low)
print('poly_coef_mid', poly_coef_mid)
print('poly_coef_high', poly_coef_high)
