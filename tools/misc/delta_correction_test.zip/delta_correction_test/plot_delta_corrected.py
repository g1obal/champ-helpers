"""
Fit a function for a given acceptance rate to correct delta values.

The result will be used in input editor.
It changes the delta value, for a given acceptance rate obtained from a VMC
run in order to ensure 0.5 acceptance rate in the next run. 
The result is the delta multiplier.

Author: Gokhan Oztarhan
Created date: 20/01/2022
Last modified: 20/01/2022
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


df = pd.read_csv('data.csv')

#mask = np.logical_and(df['acceptance'] < 0.95, df['acceptance'] > 0.05)
#df = df[mask]

df = df.sort_values('delta')

ind = (df['acceptance'] - 0.5).abs().argmin()
print(df['acceptance'].iloc[ind], df['delta'].iloc[ind])

x = df['acceptance']
y = df['delta'].iloc[ind] / df['delta']

poly_coef = np.polyfit(x, y, 15)

ratio = np.polyval(poly_coef, x)

plt.plot(x, y, 'bo')
plt.plot(x, ratio, 'rx')

print(poly_coef)

delta_corrected = pd.DataFrame(df['acceptance'], columns=['acceptance'])
delta_corrected['delta'] = df['delta']
delta_corrected['delta_corrected'] = df['delta'] * ratio
delta_corrected['diff'] = delta_corrected['delta_corrected'] - df['delta'].iloc[ind]
delta_corrected['ratio'] = ratio
delta_corrected = delta_corrected.sort_values('acceptance')

delta_corrected.to_csv('delta_corrected.csv')

plt.show()

# These parameters are currently used in input editor (20/01/2022).
POLY_COEF = [
    -8.96914127e+05, 6.62592648e+06, -2.21200940e+07, 4.41408228e+07,
    -5.86875575e+07, 5.48595716e+07, -3.70830989e+07, 1.83644274e+07,
    -6.67791146e+06, 1.77055326e+06, -3.36530353e+05, 4.44860783e+04,
    -3.87221313e+03, 1.96201108e+02, -2.13410784e+00, 2.31992931e-01,
]

