"""
Potential converter

Comparison between cylindrical dot potential versus gaussian dot potential

Author: Gokhan Oztarhan
Created date: 05/01/2022
Last modified: 21/09/2022
"""

from copy import deepcopy
from itertools import cycle

import numpy as np
import matplotlib.pyplot as plt

import au
from potential import *

eunit = 'meV'
lunit = 'nm'

m_r = 0.067
kappa = 12.4 

n_linspace = 500
n_x = 1000


def main():
    
    v = -1

    rho = 10
    rho_list = [1, 5, 10, 20]
    
    gndot_s_list = [1, 1.5, 2, 2.5, 5, 10, 20]
    
    cyldot_s_list = [0.01, 0.05, 0.1, 0.25, 0.5, 1, 5]
    
    
    xmax = rho_list[-1] * 2
    
    
    plt.ioff()
    fig = plt.figure(figsize=plt.figaspect(0.55))
    plt.rc('text', usetex=True)
    plt.rc('text.latex', preamble=r'\usepackage{amsmath}')
    
    box_aspect = 0.5
    
    ylim = [v*1.01, 0]
    
    ax = []
    
    # ax[0]
    s = 2
    ax.append(fig.add_subplot(2, 2, 1, box_aspect=box_aspect))
    ax[-1].set_title('$gndot: \ V_{0}=%.2f \ meV, \ s=%.2f$' \
        %(v,s), fontsize=8)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _rho in rho_list:
        #xmax = _rho*2
        x = np.linspace(-xmax, xmax, n_x)
        pot_gn = gndot(x, v, _rho, s)
        linestyle = next(line_cycler)
        label = '$\\rho=%.2f \ nm$'%_rho
        ax[-1].plot(x, pot_gn, label=label, **linestyle) 
        
    # ax[1]
    s = 0.25
    ax.append(fig.add_subplot(2, 2, 2, box_aspect=box_aspect))
    ax[-1].set_title('$cyldot: \ V=%.2f \ meV, s=%.2f \ nm^{-2}$' \
        %(v,s), fontsize=8)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _rho in rho_list:
        #xmax = _rho*2
        x = np.linspace(-xmax, xmax, n_x)
        pot_gn = cyldot(x, v, s, _rho)
        linestyle = next(line_cycler)
        label = '$\\rho=%.2f \ nm$'%_rho
        ax[-1].plot(x, pot_gn, label=label, **linestyle) 

    # ax[2]
    ax.append(fig.add_subplot(2, 2, 3, box_aspect=box_aspect))
    ax[-1].set_title('$gndot: V_{0}=%.2f \ meV, \\rho=%.2f \ nm$' \
        %(v,rho), fontsize=8)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _s in gndot_s_list:
        xmax = rho*3  
        x = np.linspace(-xmax, xmax, n_x)
        pot_gn = gndot(x, v, rho, _s)
        linestyle = next(line_cycler)
        label = '$s=%.2f$'%_s
        ax[-1].plot(x, pot_gn, label=label, **linestyle) 
    
    # ax[3]
    ax.append(fig.add_subplot(2, 2, 4, box_aspect=box_aspect))
    ax[-1].set_title('$cyldot: V=%.2f \ meV, \\rho=%.2f \ nm$' \
        %(v,rho), fontsize=8)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _s in cyldot_s_list:
        xmax = rho*3  
        x = np.linspace(-xmax, xmax, n_x)
        pot_gn = cyldot(x, v, _s, rho)
        linestyle = next(line_cycler)
        label = '$s=%.2f  \ nm^{-2}$'%_s
        ax[-1].plot(x, pot_gn, label=label, **linestyle) 

    for _ax in ax:
        _ax.set_xlabel('$x \ (nm)$',fontsize=10)
        _ax.set_ylabel('$V \ (meV)$',fontsize=10)
        _ax.legend(fontsize=5)       
        _ax.tick_params(labelsize=8)   
      
    #fig.tight_layout()      
    plt.subplots_adjust(wspace=0.30, hspace=0.60)
        
    fig.savefig('gndot_vs_cyldot.png',dpi=300,format='png',bbox_inches='tight') 
    plt.close(fig) 

    
def get_line_cycler():
    linestyle_list = { 
        'linestyle': ['-', '--', '-.', ':'], 
        'color': ['k', 'r', 'y', 'g', 'c', 'b', 'm']
    }    
    linestyle_grid = get_grid(linestyle_list)
    linestyle_cycler = cycle(linestyle_grid) 
    return linestyle_cycler   
    
    
def get_grid(params):
    from itertools import product
    grid = [dict(zip(params, i)) for i in product(*params.values())]
    
    return grid
    
    
if __name__ == '__main__':
    main()
    

