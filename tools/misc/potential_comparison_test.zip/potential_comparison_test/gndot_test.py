"""
Gaussian dot potential tester 

Author: Gokhan Oztarhan
Created date: 05/01/2022
Last modified: 21/09/2022
"""

from copy import deepcopy
from itertools import cycle

import numpy as np
import matplotlib.pyplot as plt

import au
from potential import *

eunit = 'meV'
lunit = 'nm'

m_r = 0.067
kappa = 12.4 

n_linspace = 500
n_x = 1000


def main():
    
    v = -40

    rho_list = [1, 5, 10, 20, 30, 40]
    cyldot_s_list = [1, 1.5, 2, 2.5, 5, 10, 50]

    
    func = gndot
    fname = 'gndot.png'
    func_view = \
        '$f(x) = V_{0} \\exp[- (x^{2} / \\rho^{2})^{s}]$'
 

    plt.ioff()
    fig = plt.figure(figsize=plt.figaspect(0.5))
    plt.rc('text', usetex=True)
    plt.rc('text.latex', preamble=r'\usepackage{amsmath}')
    
    box_aspect = 0.6
    
    fontsize = 8
    tick_labelsize = 6
    
    ylim = [v*1.01, 0]
    
    ax = []
    
    # ax[0]
    s = 1.7
    ax.append(fig.add_subplot(2, 3, 1, box_aspect=box_aspect))
    ax[-1].set_title('$s=%.2f$'%s, fontsize=fontsize)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _rho in rho_list:
        xmax = _rho*2.25 
        x = np.linspace(-xmax, xmax, n_x)
        pot_cyl = func(x, v, _rho, s)
        linestyle = next(line_cycler)
        label = '$\\rho=%.2f \ nm$'%_rho
        ax[-1].plot(x, pot_cyl, label=label, **linestyle) 
        
    # ax[1]
    s = 3.5
    ax.append(fig.add_subplot(2, 3, 2, box_aspect=box_aspect))
    ax[-1].set_title('$s=%.2f$'%s, fontsize=fontsize)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _rho in rho_list:
        xmax = _rho*1.75 
        x = np.linspace(-xmax, xmax, n_x)
        pot_cyl = func(x, v, _rho, s)
        linestyle = next(line_cycler)
        label = '$\\rho=%.2f \ nm$'%_rho
        ax[-1].plot(x, pot_cyl, label=label, **linestyle) 

    # ax[2]
    s = 10
    ax.append(fig.add_subplot(2, 3, 3, box_aspect=box_aspect))
    ax[-1].set_title('$s=%.2f$'%s, fontsize=fontsize)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _rho in rho_list:
        xmax = _rho*2.0
        x = np.linspace(-xmax, xmax, n_x)
        pot_cyl = func(x, v, _rho, s)
        linestyle = next(line_cycler)
        label = '$\\rho=%.2f \ nm$'%_rho
        ax[-1].plot(x, pot_cyl, label=label, **linestyle) 

    # ax[3]
    rho = 1
    ax.append(fig.add_subplot(2, 3, 4, box_aspect=box_aspect))
    ax[-1].set_title('$\\rho=%.2f \ nm$'%rho, fontsize=fontsize)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _s in cyldot_s_list:
        xmax = rho*2.5 
        x = np.linspace(-xmax, xmax, n_x)
        pot_cyl = func(x, v, rho, _s)
        linestyle = next(line_cycler)
        label = '$s=%.2f$'%_s
        ax[-1].plot(x, pot_cyl, label=label, **linestyle) 
        
    # ax[4]
    rho = 10
    ax.append(fig.add_subplot(2, 3, 5, box_aspect=box_aspect))
    ax[-1].set_title('$\\rho=%.2f \ nm$'%rho, fontsize=fontsize)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _s in cyldot_s_list:
        xmax = rho*2.5
        x = np.linspace(-xmax, xmax, n_x)
        pot_cyl = func(x, v, rho, _s)
        linestyle = next(line_cycler)
        label = '$s=%.2f$'%_s
        ax[-1].plot(x, pot_cyl, label=label, **linestyle) 
        
    # ax[5]
    rho = 30
    ax.append(fig.add_subplot(2, 3, 6, box_aspect=box_aspect))
    ax[-1].set_title('$\\rho=%.2f \ nm$'%rho, fontsize=fontsize)
    ax[-1].set_ylim(ylim)
    line_cycler = get_line_cycler()
    for _s in cyldot_s_list:
        xmax = rho*2.5
        x = np.linspace(-xmax, xmax, n_x)
        pot_cyl = func(x, v, rho, _s)
        linestyle = next(line_cycler)
        label = '$s=%.2f$'%_s
        ax[-1].plot(x, pot_cyl, label=label, **linestyle) 
    
    for _ax in ax:
        _ax.set_xlabel('$x \ (nm)$', fontsize=fontsize)
        _ax.set_ylabel('$v \ (meV)$', fontsize=fontsize)
        _ax.tick_params(axis='both', which='major', labelsize=tick_labelsize)
        _ax.tick_params(axis='both', which='minor', labelsize=tick_labelsize)
        _ax.legend(fontsize=4, loc='best')  

    # Add info
    ax_info = fig.add_subplot(1,1,1)
    ax_info.clear()
    ax_info.axis("off")  
    ax_info.text(0.5,1.05, func_view, ha='center', fontsize=10)      
    info_str = '$V_{0}=%.2f \ meV$' %v
    ax_info.text(0.5,1.01, info_str, ha='center', fontsize=10)    
      
    fig.tight_layout()      
        
    fig.savefig(fname,dpi=300,format='png',bbox_inches='tight') 
    plt.close(fig) 

    
def get_line_cycler():
    linestyle_list = { 
        'linestyle': ['-', '--', '-.', ':'], 
        'color': ['k', 'r', 'y', 'g', 'c', 'b', 'm']
    }      
    linestyle_grid = get_grid(linestyle_list)
    linestyle_cycler = cycle(linestyle_grid) 
    return linestyle_cycler   
    
    
def get_grid(params):
    from itertools import product
    grid = [dict(zip(params, i)) for i in product(*params.values())]
    
    return grid
    
    
if __name__ == '__main__':
    main()
    

