"""
Potential converter

Converts cyldot potential to gndot potential
Finds suitable parameters using grid search 

Author: Gokhan Oztarhan
Created date: 05/01/2022
Last modified: 21/09/2022
"""

from copy import deepcopy

import numpy as np
import matplotlib.pyplot as plt

import au
from potential import *

eunit = 'meV'
lunit = 'nm'

m_r = 0.067
kappa = 12.4 

n_linspace = 100
n_x = 1000


def main():
    cyldot_s = 0.05
    s_limits = [1.39,1.4]
                                       
    v_rho = [
        [-99, 5],
        [-50.5, 10],
        [-25, 20],
        [-15.5, 30],
        [-10.6, 40],
        [-8.9, 45],
        [-7.5, 50],
    ]
    
    for i, item in enumerate(v_rho):
        cyldot_v = item[0]
        cyldot_rho = item[1]
        s_selected, rho_selected = find_params(cyldot_v, cyldot_s, cyldot_rho, 
                                               s_limits)  
        plot(cyldot_v, cyldot_s, cyldot_rho, s_selected, rho_selected, str(i))      
    
    
def find_params(cyldot_v, cyldot_s, cyldot_rho, s_limits):
    rho_limits = [cyldot_rho/3, cyldot_rho*6]

    cyldot_v_au = au.convert_energy(cyldot_v,eunit,m_r,kappa)
    cyldot_s_au = 1.0 / au.convert_length((1.0/cyldot_s),lunit,m_r,kappa)
    cyldot_rho_au = au.convert_length(cyldot_rho,lunit,m_r,kappa)

    v_max = cyldot(0,cyldot_v_au,cyldot_s_au,cyldot_rho_au)
    xmax = radius_cyldot(5e2, cyldot_s_au, cyldot_rho_au)     

    s_range = np.linspace(s_limits[0], s_limits[1], n_linspace)
    rho_au_range = np.linspace(
        au.convert_length(rho_limits[0],lunit,m_r,kappa),
        au.convert_length(rho_limits[1],lunit,m_r,kappa),
        n_linspace
    )

    x = np.linspace(-xmax, xmax, n_x)
    pot_cyl = cyldot(x,cyldot_v_au,cyldot_s_au,cyldot_rho_au)

    l2_min = np.inf
    s_selected = 0
    rho_au_selected = 0
    for gndot_s in s_range:
        for gndot_rho_au in rho_au_range:
            pot_gn = gndot(x, v_max, gndot_rho_au, gndot_s)
            l2 = np.sum((pot_cyl - pot_gn)**2)
            if l2 < l2_min:
                l2_min = deepcopy(l2)
                s_selected = deepcopy(gndot_s)
                rho_au_selected = deepcopy(gndot_rho_au)
                
    rho_selected = au.convert_length_inverse(rho_au_selected,lunit,m_r,kappa)
    print('l2 =',l2)
    print('cyldot_v = ', cyldot_v)
    print('cyldot_s = ', cyldot_s)
    print('cyldot_rho = ', cyldot_rho)
    print('s_selected =', s_selected)
    print('rho_selected =', rho_selected,'\n')

    return s_selected, rho_selected
    
    
def plot(cyldot_v, cyldot_s, cyldot_rho, s_selected, rho_selected, fname):
    cyldot_v_au = au.convert_energy(cyldot_v,eunit,m_r,kappa)
    cyldot_s_au = 1.0 / au.convert_length((1.0/cyldot_s),lunit,m_r,kappa)
    cyldot_rho_au = au.convert_length(cyldot_rho,lunit,m_r,kappa)
    
    gndot_rho_au = au.convert_length(rho_selected,lunit,m_r,kappa)

    v_max_au = cyldot(0,cyldot_v_au,cyldot_s_au,cyldot_rho_au)
    v_max = au.convert_energy_inverse(v_max_au,eunit,m_r,kappa)
    xmax = radius_cyldot(5e3, cyldot_s_au, cyldot_rho_au)
             
    x = np.linspace(-xmax, xmax, n_x)
    pot_cyl = cyldot(x,cyldot_v_au,cyldot_s_au,cyldot_rho_au)    
    pot_gn = gndot(x, v_max_au, gndot_rho_au, s_selected)

    plt.ioff()
    fig = plt.figure(figsize=plt.figaspect(1.0))
    plt.rc('text', usetex=True)
    plt.rc('text.latex', preamble=r'\usepackage{amsmath}')
    
    plt.plot(x, pot_cyl, 'b', label='cyldot')
    plt.plot(x, pot_gn, 'r--', label='gndot')
    
    plt.xlabel('$x (au)$',fontsize=16)
    plt.ylabel('$V (au)$',fontsize=16)
    
    title = '$cyldot: v = %.5f \ meV, s = %.5f \ nm^{-1}, rho = %.5f \ nm$\n' \
            %(cyldot_v, cyldot_s, cyldot_rho) \
            + '$gndot: v = %.5f \ meV, s = %.5f, rho = %.5f \ nm$' \
            %(v_max, s_selected, rho_selected)
            
    plt.title(title, fontsize=10)

    plt.legend(fontsize=10)
    
    fig.savefig(fname+'.png',dpi=150,format='png',bbox_inches='tight') 
    plt.close(fig)    
    
if __name__ == '__main__':
    main()
    

